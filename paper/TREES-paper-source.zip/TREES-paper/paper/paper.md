# Reflective Elimination: Accumulating Design Experience in Tree-Structured Algorithm Populations

## Abstract

Evolutionary algorithm design with large language models produces a history of code changes and measured outcomes. Population selection keeps algorithms but not this history: an eliminated algorithm leaves the population together with what its development revealed. We observe that a tree-structured population already organizes this history by ancestry. Once the retained algorithms and their branching ancestors are fixed, every other algorithm lies either on a path between two retained algorithms or on a branch below one. We introduce reflective elimination, a population update that reflects on each such region as it is removed: path contraction condenses a path into experience on the reconnecting edge, and subtree pruning condenses branches into experience at their retained ancestor. Experience on removed nodes and edges enters the reflection that removes them, so accumulation continues after the original algorithms leave. Our method, TREES (Tree-structured Reflective Evolutionary Search), reuses this experience in generation: refinement and crossover read how the current algorithm was formed, and exploration reads the designs and experience of structurally different representatives. We prove that the update preserves the selected representatives and bounds the number of maintained algorithms independently of the evaluation budget. In the early stages of 12 searches on four combinatorial optimization tasks, 147 of 490 reflections inherit experience from earlier updates, and a traced case follows experience from an eliminated branch into a later generation prompt.

## 1. Introduction

Evolutionary algorithm design improves a population by generating, evaluating, and selecting algorithms. Large language models (LLMs) generate and revise executable programs, allowing search to explore beyond a fixed set of mutation rules [@funsearch; @eoh]. Each parent-offspring comparison records a change in computation and its measured outcome. Successive changes describe how an algorithm developed, while branches from a shared ancestor record different developments from the same starting point. These histories provide material for algorithm-design experience beyond the code and score of the best individual.

Using such experience requires keeping outcomes connected to the algorithms and changes that produced them. Current implementations alone do not reveal this history; keeping every evaluated algorithm in the population makes it grow throughout search. Reflection offers a way to condense design experience. ReEvo reflects on algorithm differences and performance comparisons [@reevo], and recent methods organize search history through lineages, semantic differences, and branch memories [@phyloevolve; @deltaevolve; @memorytree]. We ask how experience formation can become part of population evolution itself: when algorithms are eliminated, which histories should be summarized together, where should their experience remain, and how can subsequent design use it?

A tree-structured population connects these decisions through ancestry. Nodes represent algorithms, and parent-child relationships record their evolutionary trajectories. Retaining selected algorithms and their branching ancestors partitions the other nodes into paths connecting retained algorithms and subtrees extending from them. A path region describes development between retained endpoints; a subtree region describes branches from a retained ancestor. Reflection can condense the former onto the reconnected edge and the latter onto that ancestor. Experience then stays on the evolutionary relationships that later generation reads. **A tree-structured population thus makes algorithm survival and elimination a process of accumulating and reusing algorithm-design experience.**

We develop **TREES (Tree-structured Reflective Evolutionary Search)** to realize this idea. Its core update, **reflective elimination**, couples path contraction and subtree pruning with reflection. Each reflection reads every algorithm in the region, with its design, implementation, and outcome relative to its parent, together with the experience the region already carries. It records which change was tried from which starting computation and what followed. If a later update removes a node or edge that carries experience, that experience enters the new reflection. An algorithm can therefore leave the population while experience from its evolution remains available within it. We prove that each removed node belongs to one simplification region, that the selected representatives survive the update, and that the number of algorithm nodes after an update is bounded independently of the evaluation budget.

The same population supports continued search. Budget allocation uses current representatives' fitness ranks and the evaluations spent generating their own offspring, so a new representative can draw on ancestral experience while its allocation follows its own search history. Generation contexts follow the tree. Refinement reads how the current algorithm was formed and what has been tried from it; crossover adds a reference algorithm with its own development; exploration reads the designs and experience of structurally different representatives. Evaluated offspring then produce new histories for subsequent selection and reflection. An analysis of 12 early searches documents both forms of experience, their incorporation across updates, and the associated reflection cost.

Our contributions are:

- Reflective elimination, a population update that organizes experience accumulation through path contraction and subtree pruning. The retained tree determines which histories are summarized together and where their experience remains.
- A search procedure that uses this representation for trajectory-based refinement and crossover, exploration over structurally different representatives, and budget allocation over current representatives.
- Structural guarantees for representative preservation and population size, together with an empirical analysis of experience accumulation and reflection cost in 12 early searches.

## 2. TREES

### 2.1. A Tree-Structured Population

We consider algorithm design for a fixed function interface and evaluator. A candidate program $v$ implements a function within a solver and receives a training objective $f(v)$, with lower values preferred. Feasible programs pass the evaluator's checks and return a finite objective. Search returns the best feasible program found within $B$ program evaluations; evaluation and repair details appear in Appendix E.

The population is a rooted tree $T=(\mathcal N\cup\{v_0\},\mathcal E)$. Nodes hold evaluated algorithms, their results, and design descriptions. Evaluation failures also enter the tree. The virtual root $v_0$ connects initial individuals and has no implementation or score. Each offspring has one structural edge to its primary parent; crossover records the second algorithm as a reference. Edges therefore record generation relationships, and contracted edges record ancestry across removed nodes.

This representation gives population updates a role in organizing design experience. Paths record how algorithms develop through successive changes; branches record different developments from a shared ancestor. TREES reflects on these histories when their algorithms are eliminated, retaining edge experience $E_{u\to v}$ and node experience $E_u$ within the resulting tree. The figures abbreviate $E_{u\to v}$ as $E_{uv}$. Figure 1 shows how this experience returns to subsequent generation.

![TREES population update and search](figures/framework.png)

**Figure 1. Reflective elimination connects population turnover to experience accumulation and reuse.** (a) Retaining $A$, $B$, $C$, and the virtual root divides the other nodes into a path region ($b_1,b_2,b_3,x$) and a subtree region ($s_1$–$s_4$). (b) Elimination and reflection condense the former into edge experience $E_{AB}$ and the latter into node experience $E_A$. Both regions meet the illustrated threshold $m=4$. (c) Representatives receive evaluation budget. Refinement and crossover read how the current algorithm was formed; exploration reads the designs and experience of different representatives. The evaluated offspring $N$ enters the next update.

### 2.2. Reflective Elimination

Population selection identifies algorithms to retain. Their ancestry determines how the remaining histories can be summarized. After retaining the branching ancestors connecting the selected algorithms, the other nodes fall into two kinds of region: paths between retained nodes, including branches from intervening nodes, and subtrees extending from retained nodes. These regions associate each history with the algorithms that remain available for further design. Section 2.3 formalizes the selection and partition.

**Path contraction.** A path $u\leadsto v$ records the development from one retained algorithm to another. The code of $v$ expresses its current computation; the path records the changes and outcomes through which that computation developed. Reflection reads $u$, every intervening algorithm with its side branches, and $v$, together with the experience they carry, and condenses this development into edge experience $E_{u\to v}$. Removing the intervening nodes and reconnecting $u$ to $v$ leaves the experience attached to the relationship it describes.

**Subtree pruning.** A subtree region records branches from a retained algorithm $u$ that no longer contain a selected descendant. These branches show what was changed from $u$ and what followed, including execution failures. Reflection reads $u$ with its existing node experience and every pruned algorithm, and produces an updated node experience $E_u$. Pruning the branches leaves this account at their retained ancestor, where later generation reads it alongside the algorithm from which they developed. Both operations also apply at the virtual root: a contracted initial path carries $E_{v_0\to v}$, and pruned initial branches update root experience $E_{v_0}$.

Experience remains available for further consolidation as the population changes. If an earlier retained algorithm $D$ is later removed along $A\leadsto G$, reflection integrates $E_{AD}$ and experience on the intervening nodes and branches with the new development, producing $E_{AG}$ (Figure 2a). If more branches from $A$ are pruned, their designs and outcomes update the existing $E_A$ (Figure 2b). Experience accumulation thus continues even when the algorithms that originally carried it leave the population.

**Reflection.** Both operations use one reflection prompt. Each algorithm in the region appears once, as a record of its origin and outcome relative to its parent, its design description, its failure if any, the experience it carries, and its code. Retained parents outside the region appear with design and code as baselines. Designs let reflection write at the level of computational ideas, the level at which generation later reads experience; code exposes implementation defects that a design description omits. The prompt asks each finding to state the starting computation, the change tried, and the measured outcome, and to carry forward relevant earlier experience. A single eliminated trial confounds an idea with one implementation of it, so the prompt asks reflection not to turn such a trial into a general rule or prohibition. Appendix E.5 gives the prompt.

![Experience accumulation across successive updates](figures/reflective-simplification.png)

**Figure 2. Design experience persists through successive population updates.** (a) Removing $D$ and $u_1$–$u_3$ integrates existing edge experience $E_{AD}$ with the subsequent development into $E_{AG}$. The endpoints $A$ and $G$ remain. (b) Pruning $y_1$–$y_4$ integrates their designs and outcomes with the existing node experience $E_A$. In both examples, previously formed experience enters the later reflection; the original algorithm nodes need not remain in the population.

### 2.3. Selecting Representatives and Simplifying the Tree

The update must retain algorithms for further generation and the branching relationships needed to organize their experience. TREES selects representative algorithms first, then adds their common ancestors. This order allows an ancestor to connect retained lineages without competing with its descendants for parent selection.

Let $\mathcal P$ be the feasible nodes in $T$. Deduplicate identical normalized source and fitness by retaining the earliest node as a candidate, yielding $\mathcal D$. Order these candidates by increasing fitness, breaking ties by node ID, as $(v_1,\ldots,v_{|\mathcal D|})$. Starting from $R_0=\varnothing$, select at most $K$ representatives:

$$
\begin{aligned}
R_k &= R_{k-1} \cup \bigl\{v_k : |R_{k-1}| < K,\\
&\qquad d(v_k,u)\geq\delta\quad\forall u\in R_{k-1}\bigr\},\\
R &= R_{|\mathcal D|}.
\end{aligned}
\tag{1}
$$

Here $d$ is multiset Jaccard distance over abstract syntax tree (AST) features. The threshold $\delta$ prevents a candidate from entering $R$ when an earlier representative has sufficiently similar syntax. The best feasible algorithm enters $R$, with ties resolved by node ID. Appendix E specifies the code representation and defaults.

Let $\operatorname{LCA}_T(R)$ denote the pairwise lowest common ancestors (LCAs) of representatives. Additional branching nodes $F$ complete the retained skeleton $\mathcal H$:

$$
\begin{aligned}
F &= \operatorname{LCA}_T(R)\setminus(R\cup\{v_0\}),\\
\mathcal H &= \{v_0\}\cup R\cup F.
\end{aligned}
\tag{2}
$$

Two skeleton nodes are adjacent along a path when no other skeleton node lies strictly between them. Each nonempty intervening chain, together with its off-chain branches, forms a path region. All remaining non-skeleton branches form subtree regions grouped at their nearest skeleton ancestor. Retaining the LCAs makes these regions disjoint and assigns every non-skeleton node to exactly one region.

TREES defers simplification until a region contains at least $m$ non-skeleton nodes, allowing each reflection to consider several newly removed algorithms. For region partition $\mathcal C$, the removed union $\mathcal U$ and retained set $\mathcal K$ are

$$
\begin{aligned}
\mathcal U &= \bigcup_{C\in\mathcal C:\,|C|\geq m} C,\\
\mathcal K &= (\mathcal N\cup\{v_0\})\setminus\mathcal U.
\end{aligned}
\tag{3}
$$

All reflections use the pre-update tree. Eligible paths are then contracted and eligible subtrees pruned, with their experience attached as described in Section 2.2. Smaller regions remain in the tree. Only nodes in $R$ participate in parent sampling; branching nodes and deferred regions provide structure and context.

The update preserves the rooted tree, ancestry among retained nodes, and the representative set: $R(T')=R(T)$. Repeating it without a new insertion produces no further simplification. Once initialization is complete, every update leaves at most $4Km-2K-m$ algorithm nodes (332 for the defaults), independently of the evaluation budget. The population can therefore retain experience from earlier evolution without keeping every historical algorithm. Appendix C proves these structural properties.

### 2.4. Reusing the Population for Continued Search

The maintained population supports two connected decisions: which algorithm receives further evaluation budget, and which design experience informs its offspring. Parent sampling uses current representatives and their own offspring evaluations. Generation can also draw on the histories and experience associated with those representatives.

Let $n_r$ count evaluations spent generating offspring with representative $r$ as the primary parent, including failures and re-evaluations after repair. Let $\bar\rho_R(r)$ be its average fitness rank, with average ranks for ties, and $\Delta\bar\rho_R(r)=\bar\rho_R(r)-\min_{u\in R}\bar\rho_R(u)$. Define

$$
\begin{aligned}
w(r) &= \frac{2^{-\Delta\bar\rho_R(r)/H}}{1+n_r},\\
P(r) &= \frac{w(r)}{\sum_{u\in R}w(u)}.
\end{aligned}
\tag{4}
$$

The half-life $H$ controls the decrease in weight with fitness rank; $1/(1+n_r)$ reduces the weight as offspring evaluations accumulate. A new node starts at $n_r=0$, and simplification preserves surviving counts. A newly inserted representative therefore receives weight based on its own search history, while its ancestral trajectory and experience remain available for generation.

Each operator reads the part of the tree that matches its design task. Contexts present algorithms by outcome, design description, and experience; code appears only for the algorithms that the operator rewrites or combines. Every context begins with root experience when it exists. Appendix E.3 lists the context blocks.

**Refinement** reads the formation trajectory of the current algorithm: each algorithm on its path from the root, with its outcome relative to its parent, its design, the stage experience on its incoming edge, and the node experience at it. It also reads the node experience of the current algorithm and the evaluated attempts generated from it. The current implementation comes last.

**Crossover** reads the same context for the primary parent and adds one reference algorithm: its design, the experience along its own development not already shown, and its code. Among sufficiently fit representatives not yet paired with the primary parent, the reference is the one farthest from it in AST distance, so each combination joins structurally different computations. The prompt permits improving the primary algorithm when no useful combination emerges.

**Exploration** reads a set of representatives that spans the population: the primary parent, the best other representative, and up to five more chosen greedily to maximize the minimum AST distance to the parent and those already chosen. Each appears with its fitness, design, and the experience along its development, without code. The prompt asks for a main computation that differs from these approaches: a new way to compute the decision rather than another weighting of the same features. Presenting designs rather than code lets exploration draw on what has been tried without anchoring on an existing implementation.

Evaluated offspring enter the tree and participate in subsequent selection, elimination, and reflection. Algorithm 1 summarizes the search.

```text
Algorithm 1: TREES
Input: task interface, evaluator, LLM, evaluation budget B, initial size I
Initialize tree T with a virtual root
while evaluation budget remains and the stopping rule is not met:
    If fewer than I feasible initial programs have been collected, choose Init at the root
    Otherwise, select a representative parent and generation operator
    Construct the corresponding generation context
    Generate a candidate; evaluate it with at most one repair
    If no program was evaluated, continue
    Attach the final evaluated program to its primary parent
    If fewer than I feasible initial programs have been collected, continue
    Select representatives R and their branching skeleton H
    Partition non-skeleton nodes into path and subtree regions
    Reflect on each eligible region using the pre-update tree
    Contract paths and prune subtrees; store experience on new edges and retained nodes
return the best feasible algorithm evaluated during search
```

## 3. Analysis of Experience Accumulation During Search

### 3.1. Tasks and Analysis Scope

We examine four algorithm-design tasks: constructive tour selection for the traveling salesman problem (TSP), ant colony heuristics for the capacitated vehicle routing problem (CVRP) and orienteering problem (OP), and guided local-search perturbations for the permutation flow-shop scheduling problem (FSSP). Each task fixes the outer solver and evolves one decision function. Every candidate is evaluated on 16 fixed training instances. Searches use Qwen3.8-27B, seeds 0–2, and the method in Section 2 with $K=24$, $\delta=0.15$, and $m=4$. Appendix D specifies the tasks, data, and evaluation protocol.

The analysis covers the first 243–363 program evaluations of 12 searches, 3,519 in total. We compare trajectories at the common horizon of 240 evaluations and use each entire captured prefix to examine reflection. The analysis asks how elimination forms experience, whether that experience enters subsequent updates and generation, and how these processes coexist with continued algorithm development.

### 3.2. Experience Formation and Inheritance

The searches inserted 3,271 algorithm nodes and removed 2,301 through 490 reflective elimination updates. The removed algorithms formed 192 path regions and 298 subtree regions. These regions contribute complementary histories: development between retained endpoints and branches from a retained ancestor. At capture, each tree contains 66–99 algorithms.

In 147 of the 490 reflections ($30.0\%$), the experience supplied to reflection contains a complete text produced by a strictly earlier update: 87 path reflections and 60 subtree reflections. Experience thus re-enters reflection as the population changes. Appendix D.5 defines the matching procedure.

A TSP case makes this inheritance concrete. At evaluation 97, a path and its branches are condensed onto edge $17\to70$. At evaluation 104, a larger region removes node 70 and incorporates that edge experience into a new summary on $13\to66$. A subsequent refinement of node 66 receives the new summary in its actual generation prompt. The resulting program changes the candidate width and tail-search effort. Appendix F traces the code, scores, and two reflections, including the offspring's slight regression.

### 3.3. Reflection Granularity and Cost

Each reflected region contains 4–12 newly removed algorithms, with a median of 4 and a mean of 4.70. Reflection consumed 3,959,071 input tokens and 88,604 output tokens, 8,080 and 181 per region on average, and all 490 calls returned a valid experience. A reflection thus reads several related implementations, their outcomes, and the experience they carry, and returns a short account for later design. Inherited experience extends this account beyond the newly removed nodes to earlier development.

### 3.4. Population Turnover and Search Progress

![Best training fitness and number of retained algorithms](figures/representative-search.png)

**Figure 3. Training fitness and population size under reflective elimination.** Upper panels show best training fitness; lower panels show the number of algorithm nodes after each evaluated attempt. Curves represent seeds 0–2 over the same first 240 program evaluations. All runs use the representative-cover and region-batching rules in Section 2.

Figure 3 relates continued optimization to population turnover. The trees repeatedly admit new algorithms and remove earlier regions while the best training objective improves. At evaluation 240, mean objectives are 5.7574 for TSP, 8.1584 for CVRP, 3893.60 for FSSP, and -14.3552 for OP. Table 1 gives the individual runs and their variation. Experience accumulates while the search continues to improve.

**Table 1. Best training fitness at evaluation 240 (lower is better).** Mean and sample standard deviation (SD) are computed across three search seeds.

| Task | Seeds 0 / 1 / 2 | Mean | SD |
| --- | ---: | ---: | ---: |
| TSP | 5.7530 / 5.7372 / 5.7820 | 5.7574 | 0.0227 |
| CVRP | 8.0656 / 8.2830 / 8.1266 | 8.1584 | 0.1122 |
| FSSP | 3902.12 / 3888.88 / 3889.81 | 3893.60 | 7.39 |
| OP | -14.5419 / -14.0794 / -14.4444 | -14.3552 | 0.2438 |

## 4. Related Work

**Evolutionary algorithm design.** Genetic programming searches over executable structures [@koza], hyper-heuristics search over heuristics [@hh], and algorithm configuration searches parameter settings [@irace]. LLMs extend the variation available to program search through generated mutations and combinations [@elm; @lmcrossover; @survey_aad]. FunSearch evolves programs within island populations [@funsearch], while EoH evolves design descriptions together with code [@eoh]. LLaMEA and AlphaEvolve further develop evaluation-guided evolutionary coding [@llamea; @alphaevolve]. Population design remains consequential: HSEvo uses harmony search to balance diversity and convergence [@hsevo], PartEvo maintains niches [@partevo], and ShinkaEvolve combines fitness and sampling frequency in parent selection [@shinka]. These methods establish the setting in which TREES studies experience accumulation during population turnover.

**Evolutionary structure in search.** MCTS-AHD combines Monte Carlo tree search [@uct] with path context for heuristic generation [@mctsahd], and Clade-AHD uses descendant evaluations for clade selection [@cladeahd]. A2DEPT organizes candidates through evolutionary program trees [@a2dept]. PhyloEvolve uses phylogenetic trajectories and an elite pool for cross-lineage reuse [@phyloevolve]. PathWise organizes planning and reflection around an entailment graph [@pathwise]. These approaches illustrate how relationships between algorithms can inform selection or generation. TREES additionally uses those relationships to organize reflection when algorithms are removed, and to carry the resulting experience through later tree updates.

**Reflection and experience.** Self-Refine uses iterative self-feedback [@selfrefine], Reflexion carries verbal reflections across attempts [@reflexion], and ExpeL extracts reusable insights from task experience [@expel]. Within algorithm design, ReEvo turns performance comparisons into reflective guidance [@reevo]. RefineEvo combines planning with positive and negative experience pools [@refineevo], MeEvo interleaves evolution with shared-history reflection [@meevo], and BEAM combines bi-level algorithm optimization with adaptive memory [@beam]. DeltaEvolve organizes semantic modifications in a multi-level database [@deltaevolve]. MEMOIR maintains branch-local memory and transfers condensed experience into global memory when a branch terminates [@memorytree].

Reflective elimination couples experience formation to population turnover in TREES. The retained algorithms and their ancestry determine both the histories summarized together and the placement of their summaries. Path contraction and subtree pruning update algorithms and experience in the same tree, allowing later reflection and generation to use experience from algorithms that have already left the population.

## 5. Discussion

Reflective elimination gives population turnover a role in organizing design experience. A retained algorithm supplies a reference for the branches pruned from it, and retained endpoints supply references for the development between them. These associations explain why the experience remains relevant to the structure of subsequent design: refinement follows one history, crossover brings in a second algorithm with its own history, and exploration surveys structurally different representatives. Later simplification can change where experience resides while incorporating it into a new account of the corresponding development.

Experience affects search only through generation. Representative selection, region partitioning, and parent sampling do not read experience text, so at a fixed tree state, hiding experience from generation contexts leaves the representative set and parent probabilities unchanged. The contribution of experience is therefore measurable by ablation: the same search with experience hidden keeps every selection rule and isolates what accumulated experience adds to generation.

## 6. Conclusion

We introduced reflective elimination to make population turnover a process of accumulating algorithm-design experience. TREES implements this update in a tree-structured population, where path contraction and subtree pruning associate experience with retained algorithms and their evolutionary relationships. That experience can enter later reflection and generation after its original algorithms have left the population. The structural analysis bounds the number of maintained algorithm nodes, while the search records document experience passing across updates. Population evolution thereby supports the continued accumulation and reuse of its design experience.

## AI Use Statement {.unnumbered}

Generative AI tools assisted with literature synthesis, manuscript drafting and revision, checks against the implementation, and mechanism-figure preparation. The LLMs used within TREES are described in Sections 2 and 3 and Appendix D. The authors remain responsible for the manuscript and its claims.

## Impact Statement {.unnumbered}

This work studies automated algorithm design. Its potential benefits include reducing the manual effort required to develop computational methods. The broader consequences of the generated algorithms depend on the tasks and applications in which they are used.

## References

References are rendered from `references.bib` in the accompanying PDF.

## Appendix A. Background and Related Approaches

Appendices A–B provide background and explain the mechanism; Appendix C proves its structural properties. Appendices D–E specify tasks, evaluation, implementation, and prompts. Appendix F traces experience through two real updates and a subsequent generation call.

### A.1. Algorithm Design within a Fixed Solver

The search variable in automated algorithm design is an executable decision procedure. A candidate is evaluated by inserting it into a solver and running that solver on a collection of instances. This differs from directly searching for a tour or schedule on one instance. The four tasks in Appendix D share this formulation, but expose different decisions: the next move of a constructive method, a static heuristic for ant colony optimization, or a perturbation for local search.

Genetic programming and hyper-heuristics provide established ways to search executable structures and heuristic rules [@koza; @hh]. LLM-based methods expand the available variation through code generation. FunSearch organizes programs in islands; EoH evolves explanations alongside implementations [@funsearch; @eoh]. TREES retains this evaluation-driven setting and studies how the changing population can also organize experience from its own development.

### A.2. Where Prior Experience Enters Search

ReEvo turns algorithm comparisons into short-term reflections and accumulates longer-term reflective guidance [@reevo]. PhyloEvolve uses phylogenetic trajectories and an elite pool to expose algorithm development across lineages [@phyloevolve]. DeltaEvolve represents semantic modifications at several levels of detail and progressively reveals them to generation [@deltaevolve]. These approaches motivate retaining relationships between changes and outcomes, rather than relying only on a candidate's final score.

TREES makes population elimination the event that forms experience. The retained skeleton determines the regions to summarize and the edges or ancestors that receive their summaries. If these locations later disappear, their experience enters the next regional reflection. The distinction is therefore the coupling between population change, reflection scope, and experience placement.

### A.3. Trees, Planning, and Branch Memory

MCTS-AHD uses tree search to allocate exploration among generated heuristics [@mctsahd]. PathWise uses an entailment graph with a policy agent, a world model, and critics for planning and reflection [@pathwise]. TREES uses ancestry to organize retained algorithms and their experience; parent sampling follows Eq. (4), without a separate planning agent.

MEMOIR compresses branch-local memory into global memory when a branch terminates [@memorytree]. TREES also summarizes histories that leave active search, but distinguishes development between retained endpoints from branches attached to a retained ancestor. The resulting experience stays at these two kinds of locations in the evolving population. RefineEvo combines planning with positive and negative experience pools [@refineevo]. In TREES, empirical outcomes can be favorable or unfavorable within the same regional account; their placement follows the originating evolutionary relationship.

## Appendix B. Further Explanation of the Mechanism

### B.1. Why Retain Branching Ancestors?

Representatives identify algorithms available for further generation. Their common ancestors serve a different purpose: they preserve where the retained developments diverged. Without a retained branching ancestor, an eliminated branching region could lead to several retained descendants, leaving no single edge on which to place its account. Adding pairwise LCAs gives each path region two retained endpoints and each remaining subtree region one retained attachment. This is why the skeleton is constructed after representative selection.

A branching ancestor need not be a representative. It can preserve a reference for two descendants without taking either descendant's place in parent sampling. Conversely, a deferred off-skeleton node can remain as part of an incomplete region without receiving generation budget. Population membership and parent eligibility thus have distinct roles.

### B.2. What Do Edge and Node Experience Describe?

Edge experience describes development between two retained endpoints, including branches removed with the intervening chain. Node experience describes developments from a retained ancestor whose branches are pruned. A pruned subtree may contain feasible improvements as well as regressions and failures. Its experience records each as a starting computation, a change, and an outcome, so an idea that left the representative set remains available to later generation as a documented attempt from the retained ancestor.

Both forms of experience are interpreted alongside retained algorithms. The endpoint implementation tells the generator what computation is available now, while the experience supplies observations from its development. When a carrier is removed, its experience enters the reflection of the enclosing region. This inheritance is recursive: it propagates a condensed account, not a verbatim history. Appendix F shows an edge summary passing into a larger path reflection when its former endpoint becomes a removed side branch.

### B.3. How Does the Representation Support Continued Search?

Refinement reads the formation trajectory of one algorithm and the attempts made from it. Crossover adds a second algorithm, the experience along its development, and its implementation. Exploration reads the designs and experience of structurally different representatives, without code. These contexts expose different relationships already present in the same population. Appendix E.3 lists their blocks, and Appendix E.4 gives the instructions.

Budget allocation uses the current representatives' fitness ranks and their own offspring evaluation counts. Ancestral experience can therefore inform a new representative without transferring an ancestor's accumulated evaluation count to it. At a fixed tree state, hiding experience text leaves selection and sampling unchanged. This separates the allocation rule from the information supplied to generation.

## Appendix C. Structural Properties of Reflective Elimination

Consider a finite rooted tree $T_0=(\mathcal N_0\cup\{v_0\},\mathcal E_0)$ with representative set $R(T_0)$, branching-node set $F(T_0)$, skeleton $\mathcal H(T_0)$, region partition $\mathcal C(T_0)$, removed union $\mathcal U$, and post-update tree $T_1$ on surviving nodes $\mathcal K=(\mathcal N_0\cup\{v_0\})\setminus\mathcal U$. Assume $K,m\geq1$ and $\delta\in[0,1]$. Code, fitness, node IDs, and offspring evaluation counts of surviving nodes are unchanged during simplification.

**Rooted-tree preservation.** Because $v_0\in\mathcal H(T_0)\subseteq\mathcal K$, every surviving node $v\in\mathcal K\setminus\{v_0\}$ has a unique nearest surviving ancestor $a(v)\in\mathcal K$ along its $T_0$-ancestry path. Reconnecting unkept parents to $a(v)$ strictly decreases $T_0$-depth at every step, preventing cycles and guaranteeing a unique incoming edge per node in $\mathcal K\setminus\{v_0\}$. Thus $T_1$ is a valid rooted tree.

**Exact disjoint region partitioning.** Interior chains $C_{\text{chain}}(u,v)$ between adjacent skeleton nodes $u,v\in\mathcal H(T_0)$ are pairwise disjoint: if two chains shared an off-skeleton node, their deepest shared node would be the LCA of two distinct subtrees containing elements of $R(T_0)$, contradicting $\operatorname{LCA}_{T_0}(R(T_0))\subseteq\mathcal H(T_0)$. Every remaining node $w\in\mathcal N_0\setminus\mathcal H(T_0)$ outside all chain interiors has a unique first ancestor in $\mathcal H(T_0)\cup\bigcup C_{\text{chain}}$: if that ancestor lies in $C_{\text{chain}}(u,v)$, $w$ joins the path region for $(u,v)$; otherwise that ancestor lies in $\mathcal H(T_0)$ and $w$ joins its subtree region. Hence $\mathcal C(T_0)$ partitions $\mathcal N_0\setminus\mathcal H(T_0)$, and thresholding by $|C|\geq m$ removes disjoint regions where each removed node belongs to exactly one region.

**Champion retention and representative invariance.** When $\mathcal P_0\neq\varnothing$, its best node under the fitness-and-ID ordering enters $R(T_0)\subseteq\mathcal K$. Every representative remains the earliest surviving node for its `(identity(code), f)` key, so it remains a candidate in $\mathcal D(T_1)$. Consider the greedy scan of $\mathcal D(T_1)$ in order. By induction, suppose its accepted nodes so far are exactly the preceding representatives of $T_0$. An original representative is accepted because it encounters the same accepted prefix as before. For any other candidate $w$, let $w_0$ be the earliest node with its key in $T_0$, possibly $w$ itself. Node $w_0$ was rejected in the original scan and occurs no later than $w$. Its rejecting condition was either coverage by an earlier representative or exhaustion of the $K$ slots. Those representatives all survive and still precede $w$; identical normalized code gives $w$ the same AST features as $w_0$. Thus $w$ is rejected as well. Induction gives $R(T_1)=R(T_0)$. Fitness ranks and counts $n_r$ remain unchanged, so Eq. (4) gives the same parent probabilities before and after simplification whenever $R$ is nonempty.

**Strict single-step idempotence.** Because $R(T_1)=R(T_0)$ and contracting non-skeleton chains preserves pairwise LCAs among nodes of $R(T_0)$, we obtain $F(T_1)=F(T_0)$ and $\mathcal H(T_1)=\mathcal H(T_0)$. Consequently, $\mathcal N_1\setminus\mathcal H(T_1)=(\mathcal N_0\setminus\mathcal H(T_0))\setminus\mathcal U$ decomposes into the exact deferred regions $\{C\in\mathcal C(T_0):|C|<m\}$. Every region in $\mathcal C(T_1)$ therefore satisfies $|C|<m$, and re-running maintenance on $T_1$ without new insertions removes zero nodes and triggers zero reflection calls.

**Experience coverage.** Each removed algorithm belongs to one selected region. The reflection on that region reads the algorithm's design, implementation, and outcome, together with the existing experience on its node and incoming edge. A path reflection also reads the experience on the edge entering the retained lower endpoint, which the contracted edge replaces; a subtree reflection also reads the existing experience at the retained ancestor, which the new experience replaces. Thus every experience text that an update removes or replaces appears in the input of the reflection that replaces it. If that call fails, the update carries these texts forward unchanged.

**A bound on the number of algorithm nodes.** Let $r=|R(T_0)|\geq1$ and $h=|\mathcal H(T_0)|$. In the tree connecting the representatives and root, every additional non-root branching ancestor has at least two children, and every leaf is a representative. Hence $|F(T_0)|\leq r-1$ and $h\leq2r\leq2K$. There are at most $h-1$ path regions, one for each edge of the skeleton, and at most $h$ subtree regions, one per skeleton node. After the update, idempotence implies that every remaining region contains at most $m-1$ nodes. Excluding the virtual root, the number of algorithm nodes therefore satisfies $|\mathcal N_1|\leq(h-1)+(2h-1)(m-1)\leq4Km-2K-m$. If $R(T_0)=\varnothing$, the skeleton contains only the root and at most one subtree region remains, with $|\mathcal N_1|\leq m-1$, which also satisfies the bound. For $K=24$ and $m=4$, the bound is 332 algorithm nodes. Search performs these updates once initialization is complete.

## Appendix D. Tasks and Evaluation Protocol

### D.1. Search Interfaces and Objectives

All tasks evolve one function inside a fixed solver. The three solver frameworks expose distinct computational roles: selecting a committed move, setting a static search prior, and constructing a local-search perturbation.

**Table 2. Evolved decisions and fixed solver conditions.** Objectives are averaged over the evaluation instances and minimized.

| Task | Evolved decision | Fixed solver and objective |
| --- | --- | --- |
| TSP | Next unvisited node | Sequential tour construction; tour length |
| CVRP | Static edge heuristic matrix | 30 ants, 100 iterations; total route length |
| OP | Static edge heuristic matrix | 20 ants, 50 iterations; negative collected reward |
| FSSP | Perturbed times and selected jobs | NEH initialization, 200 search iterations; makespan |

**TSP.** A tour visits all 50 nodes and returns to its start. Coordinates are uniform in the unit square. The evolved function receives the current node, start node, unvisited node IDs sorted by distance from the current node, and the full symmetric distance matrix. It returns one unvisited node ID. The outer solver starts at node 0, repeatedly commits that choice, and appends the final remaining node and closing edge. Training instances use seed 2024.

**CVRP.** Each instance has 50 customers with coordinates uniform in the unit square and a depot at $(0.5,0.5)$. Demands are integers from 1 to 9; vehicle capacity is 50. The evolved function receives distances, coordinates, demands, and capacity and returns an edge heuristic matrix. It is called once per instance; the fixed ant colony solver combines the resulting matrix with pheromone and a capacity-feasibility mask throughout search. Entries are shifted by $10^{-9}$ and clipped below at $10^{-9}$. A seeded stream (1234) generates disjoint dataset splits; the ant colony solver also uses seed 1234.

**OP.** An instance has 50 nodes, including a depot, with unit-square coordinates and a route-length limit of 3. Node prizes increase with distance to the depot: $1+\lfloor99d_i/d_{\max}\rfloor$, normalized by the largest prize. The evolved function receives prizes, distances, and the length limit and returns one static edge heuristic matrix. Nonpositive entries are clipped to $10^{-9}$. The fixed ant colony solver masks moves that would prevent returning within the length budget. Training and test coordinates use seeds 1234 and 4567; ant colony sampling uses seed 1234. The evaluator returns negative mean reward.

**FSSP.** A single job permutation is processed on 20 machines for 50 jobs. Processing times are independently sampled integers from 1 to 99. NEH initialization is followed by local descent with swap and insertion moves, using at most three descent passes per iteration. The evolved function receives the current permutation and processing-time matrix and returns a finite, nonnegative matrix of the same shape plus one to five distinct job IDs. These outputs define a perturbation step using improving swaps or insertions involving the selected jobs. All reported makespans use the original processing times. Instances use the base seed 20261007 with split- and instance-specific seed sequences.

### D.2. Evaluation and Result Selection

Each candidate is evaluated on 16 fixed training instances. Execution uses a total budget of 160 instance-seconds across up to eight workers, measured as the sum of elapsed instance times, including running instances. On Linux, the data-segment limit of each worker is its initial usage plus 2 GiB, subject to any tighter existing limit. Instance $i$, indexed from zero, uses evaluation seed $730241+i$.

The configured search limit is 1,000 program evaluations. Failed executions and evaluations of repaired programs count toward this limit. The best training program is the search output. The held-out protocol evaluates this frozen program on 50 disjoint same-scale instances, with 500 pooled instance-seconds. Generalization tests evaluate the same frozen TSP, CVRP, and OP functions at 100 and 200 nodes.

### D.3. Comparison Methods and Budget Accounting

The comparison set comprises EoH [@eoh], ReEvo [@reevo], MCTS-AHD [@mctsahd], RefineEvo [@refineevo], and PathWise [@pathwise]. These methods cover population evolution, reflective guidance, tree search, and planning with experience. Their implementations use the same four task interfaces and evaluator conditions.

A common nominal budget does not always denote a common number of program evaluations: implementations can count generation samples, planner calls, or evaluated candidates. The comparison protocol therefore records actual evaluator invocations separately from LLM calls and token usage. Training trajectories are aligned by program evaluations; final algorithms are selected using training fitness and assessed on the held-out split.

### D.4. Language Model and Search Settings

All 12 analyzed runs use Qwen3.8-27B with native thinking disabled and seeds 0, 1, and 2. Generation uses temperature 1.0, top-$p$ 0.8, top-$k$ 20, presence penalty 1.5, and at most 16,384 output tokens. Reflection uses temperature 0.3 and at most 1,536 output tokens. Each call records its token usage. The common task prompt provides the problem, score direction, and function signature. Solver iteration counts and evaluation limits are fixed externally.

### D.5. Trace Analysis

The analyzed records contain 243–363 program evaluations per run. We align the fitness and tree-size curves at 240 evaluations, the largest multiple of ten available in all runs. Reflection counts use each run's full captured prefix. The associated configuration uses representative coverage with $K=24$, $\delta=0.15$, and region threshold $m=4$.

A reflection counts as incorporating earlier experience when the experience supplied in its input contains, after whitespace normalization, a complete output from a strictly earlier update. Outputs from the same update are excluded. This yields 87 of 192 path reflections and 60 of 298 subtree reflections. The statistic measures experience supplied to reflection. Generation reuse is checked separately against the actual prompt in Appendix F.

Region sizes count newly removed algorithms, including side branches of path regions. Their frequencies are 326 regions of size 4, 71 of size 5, 50 of size 6, 21 of size 7, 12 of size 8, 5 of size 9, 2 each of sizes 10 and 11, and 1 of size 12. These sum to 490 reflections and 2,301 removed nodes. Archived programs remain available for analysis and final-result selection; generation contexts are assembled from the maintained tree.

## Appendix E. Implementation and Prompt Specification

### E.1. Representation and Selection

**Table 3. Default method settings.** These settings are used in the analyzed runs.

| Component | Default setting |
| --- | --- |
| Initialization and budget | $I=5$ feasible initial programs; $B=1{,}000$ program evaluations in total |
| Representatives | $K=24$, $\delta=0.15$; one candidate per normalized source and fitness |
| Region threshold | $m=4$ |
| Parent sampling | Over $R$; rank half-life $H=10$; offspring-evaluation factor $1/(1+n_r)$ |
| Operator probabilities | Refinement 0.45; exploration 0.30; crossover 0.25 |
| Crossover reference | Rank quality $q(u)\geq0.30$; unused pair first; largest $d(p,u)$ |
| Exploration references | Best other representative, then up to five by largest minimum distance |

**Code representation.** After removing docstrings, TREES counts AST parent-child tag pairs and bigrams from a depth-first traversal. Tags encode node kinds, operator types, and called function or attribute names; other identifiers and constants are omitted. The distance $d(u,v)$ is the multiset Jaccard distance between these features. Duplicate detection is stricter: it compares parsed source, ignoring layout, comments, and docstrings, and requires equal fitness. It applies to the maintained tree, so a regenerated copy of an eliminated implementation enters as a new node.

**Reference selection.** For a primary parent $p$, let the other $M$ representatives have zero-based fitness ranks $\rho(u)$, with ties at their average rank. Their rank quality is $q(u)=1-\rho(u)/(M-1)$, or $0.5$ when $M=1$, and representatives with $q(u)\geq0.30$ are eligible. Among eligible references not yet paired with $p$, or among all eligible references once every pair has been used, the reference maximizes $d(p,u)$, with ties broken by better fitness and then smaller node ID. Because the choice is deterministic, preferring unused pairs rotates each parent through its eligible references. If none is eligible, the operator becomes refinement. Exploration references start from the best representative other than $p$ and repeatedly add the one whose minimum distance to $p$ and the chosen references is largest, up to six.

**Tree updates.** All reflections in one update read the same pre-update tree. A contracted edge records no operator or reference. Retained nodes keep their offspring evaluation counts.

### E.2. Evaluation, Repair, and Stopping

**Evaluation and repair.** Feasible initial programs are collected within the total budget. Each generation attempt permits at most one repair in total, either for output format or for a program that fails evaluation. Runtime repair is attempted only if evaluation budget remains. A repaired program consumes another evaluation when evaluated; format repair itself does not. Only the final evaluated program becomes a tree node. All evaluator calls count toward $B$ and, outside initialization, the primary parent's $n_r$.

**Reflection failures and stopping.** If a reflection call fails or returns an empty experience, the update stores the experience texts already present in the region, so elimination does not discard existing experience. Search stops when the budget is exhausted or after 10 consecutive attempts without a program evaluation.

### E.3. Generation Context

Every generation prompt has the same frame: the task description and score definition, the function interface, the operator context, the operator instruction, and an output specification. The output is a JSON object with an `analysis` of the chosen computation, the complete `code`, and a factual `design` description of what the code computes; this description becomes the node's design. Context blocks run from global to local and from past to present, so the code to be modified comes last (Table 4).

**Table 4. Generation context blocks in prompt order.**

| Operator | Context blocks | Code shown |
| ---------- | ---------------------------------------------------- | -------------- |
| Refinement | Initial-population experience; evolution path; attempts from the current algorithm; current algorithm | Current algorithm |
| Crossover | Initial-population experience; evolution path; attempts from the current algorithm, excluding the reference; reference algorithm; current algorithm | Current and reference algorithms |
| Exploration | Initial-population experience; representative algorithms | None |

The evolution path lists each algorithm from the root to the current algorithm with its outcome relative to its parent, its design, the stage experience on its incoming edge, and the node experience at it; a contracted edge appears as a compressed development. The attempts block opens with the node experience of the current algorithm and lists its evaluated children in creation order, each with its outcome or failure, design, and experience. Reference and representative cards give fitness, design, and the experience along the algorithm's path from the root that has not already appeared in the prompt. Initialization prompts show the fitness and design of earlier initial programs and ask for a different main computation. The experience ablation removes every experience line and leaves all other blocks and the parent probabilities unchanged.

### E.4. Generation Instructions

Each prompt ends its context with one of the following instructions, reproduced verbatim.

**Refinement.**

> Improve the current algorithm by examining how it makes decisions and where its computation can be improved. Use the implementation, outcomes, and development experience to choose a meaningful modification. You may revise its representation, decision logic, or search procedure as well as its parameters; implement a coherent improved algorithm.

**Crossover.**

> Understand the computational ideas in both implementations and develop an algorithm that combines their useful strengths. Use their development and experimental experience to reason about how the computations fit together. If no useful combination emerges, improve the current algorithm using what the comparison reveals.

**Exploration.**

> Rethink how this task can be solved and implement an alternative whose main computation differs from the existing approaches. Develop a new way to compute the decision, rather than another weighting of the same local features. The algorithms and experience above are starting points for ideas, not a structure you must preserve. Consider changes in the information used, the representation, or the procedure that produces the decision. Choose an approach suited to the task and implement its main computation.

### E.5. Reflection Prompt

All reflections use one template, reproduced verbatim below. `{problem}` contains the task description, score definition, and function interface. `{records}` lists the region as described in Section 2.2: retained baselines first, then the removed algorithms in creation order, then the retained endpoint of a path. `{history_note}` reads: "A compressed development stands for removed intermediate algorithms and is summarized by its stage experience. Experience from attempts at an algorithm summarizes removed attempts that started from it." Table 5 gives `{situation}` and `{placement}` for each kind of region.

> `{problem}`
>
> `[Algorithms]`\
> `{situation}` Each record gives the origin and outcome, the design, the failure if any, earlier experience, and the code. `{history_note}`
>
> `{records}`
>
> `[Task]`\
> Summarize the algorithm-design experience from the algorithms above. It will be stored `{placement}`.\
> For each finding, state the starting computation, the change tried, and the measured outcome. Carry forward the relevant earlier experience. Do not turn a single trial into a general rule or prohibition.
>
> `[Output]`\
> Return one JSON object with an "experience" string of about 120 words. Name computations, not algorithm numbers: the removed algorithms will not appear later.

**Table 5. Region-specific text in the reflection prompt.** $u$, $v$, and $p$ are node numbers; $\pi$ lists the removed chain followed by $v$; $o$ is the endpoint change, such as `6.6737 -> 6.1775 (improved)`.

| Region | `{situation}` | `{placement}` |
| -------- | ---------------------------------------------- | ---------------------------- |
| Path $u\leadsto v$ | Algorithm $v$ developed from Algorithm $u$ along $\pi$; overall $o$. The intermediate algorithms and their side branches will be removed, and Algorithm $u$ will lead directly to Algorithm $v$. | with Algorithm $v$ as the experience of how it developed from Algorithm $u$ |
| Path $v_0\leadsto v$ | Algorithm $v$ developed from the initial population along $\pi$. The intermediate algorithms and their side branches will be removed. | with Algorithm $v$ as the experience of how it developed from the initial population |
| Subtree at $p$ | The algorithms below are attempts that started from Algorithm $p$, directly or through other removed attempts. They will be removed; Algorithm $p$ stays. | with Algorithm $p$ as the experience from attempts that started from it |
| Subtree at $v_0$ | The algorithms below are initial algorithms and attempts derived from them. They will be removed from the population. | as the experience from the initial population |

## Appendix F. Case Study: Experience Outlives Its Original Carrier

### F.1. Selection and Evolutionary Structure

We select the earliest TSP update that incorporates an earlier edge summary, removes its former endpoint, and makes the new summary available in a later recorded generation prompt. Ties are resolved by seed and the time of the earlier reflection. This selects seed 2, with reflections after evaluations 97 and 104. Program IDs below identify the archived implementations; they are not evaluation indices.

Two developments share ancestor $v_{17}$. One follows $v_{17}\to v_{19}\to v_{36}\to v_{70}$, moving from recursive lookahead to outgoing-edge estimates and then MST-based completion estimates, with exact enumeration for small remainders. Another follows $v_{17}\to v_{20}\to v_{66}$. It replaces a static completion estimate with an explicit remaining path, built by nearest neighbor and refined by limited 2-opt moves. Both branches already exist before the first reflection.

![Recorded lineage fitness and reflection times](figures/inheritance-case.png)

**Figure 4. Two recorded TSP developments and subsequent experience inheritance.** Points show training fitness when the selected programs were evaluated; connecting lines follow their original parent relations. Vertical lines mark the later reflection updates. The complete removed regions also include side branches specified in Appendix F.2. The creation of $v_{66}$ precedes both reflections; $v_{98}$ is generated afterward.

### F.2. From a Branch Summary to a Broader Development Account

At evaluation 97, the update retains $v_{17}$ and $v_{70}$, removes intermediate nodes 19 and 36 together with branches 39 and 42, and forms $E_{17\to70}$. Its text describes the shift toward MST-based estimates and changes to the exact-enumeration threshold. Training fitness along this branch is 7.5490, 7.0604, 6.7022, and 6.6737. These are outcomes of whole programs, whose changes can affect several computations together.

At evaluation 104, the update retains $v_{13}$ and $v_{66}$ and removes nodes 17 and 20 together with branches 22, 53, and 70. The prior $E_{17\to70}$ appears in the earlier-experience block of this reflection. The new $E_{13\to66}$ describes development toward explicit tail construction and 2-opt refinement, while retaining observations about small-remainder enumeration. Thus experience from the removed MST branch contributes to the account associated with a different retained descendant. The retained endpoint $v_{66}$ has training fitness 6.1775.

### F.3. Entry into a Subsequent Generation Prompt

The first later generation call containing the complete new summary refines $v_{66}$ in attempt 98. Its prompt includes the ancestral path, current implementation, local offspring, and $E_{13\to66}$. The resulting program uses a fixed candidate width of eight instead of a width decreasing with tour progress, and adjusts the number of permitted 2-opt moves with remaining-path size. Its fitness is 6.2072, slightly worse than the parent's 6.1775.

The record follows experience from elimination through inheritance into a generation context. It also shows why TREES asks reflection for the starting computation, the change, and the outcome rather than for general rules (Section 2.2): the later summary favors constructive completion over static estimates, yet the compared programs differ in several choices at once, and the next modification does not improve its parent. The archived summaries and generation response are retained verbatim in the accompanying case record.
